import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Switch } from "../ui/switch";
import { Checkbox } from "../ui/checkbox";
import { Calendar, Clock, CalendarDays } from "lucide-react";

interface Step4CalendarPreferencesProps {
  formData: any;
  updateFormData: (data: any) => void;
}

const daysOfWeek = [
  { id: "monday", label: "Lundi" },
  { id: "tuesday", label: "Mardi" },
  { id: "wednesday", label: "Mercredi" },
  { id: "thursday", label: "Jeudi" },
  { id: "friday", label: "Vendredi" },
  { id: "saturday", label: "Samedi" },
  { id: "sunday", label: "Dimanche" },
];

export function Step4CalendarPreferences({ formData, updateFormData }: Step4CalendarPreferencesProps) {
  const workDays = formData.workDays || ["monday", "tuesday", "wednesday", "thursday", "friday"];

  const toggleWorkDay = (dayId: string) => {
    const newDays = workDays.includes(dayId)
      ? workDays.filter((id: string) => id !== dayId)
      : [...workDays, dayId];
    updateFormData({ workDays: newDays });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2>Préférences Calendrier</h2>
        <p className="text-muted-foreground mt-1">
          Configurez votre calendrier selon vos besoins
        </p>
      </div>

      <div className="space-y-6">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-primary" />
            <Label htmlFor="defaultView">Vue par défaut</Label>
          </div>
          <Select
            value={formData.defaultView || "week"}
            onValueChange={(value) => updateFormData({ defaultView: value })}
          >
            <SelectTrigger id="defaultView">
              <SelectValue placeholder="Sélectionnez la vue" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day">Jour</SelectItem>
              <SelectItem value="week">Semaine</SelectItem>
              <SelectItem value="month">Mois</SelectItem>
              <SelectItem value="agenda">Agenda</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <CalendarDays className="w-5 h-5 text-primary" />
            <Label htmlFor="startDay">Premier jour de la semaine</Label>
          </div>
          <Select
            value={formData.weekStartDay || "monday"}
            onValueChange={(value) => updateFormData({ weekStartDay: value })}
          >
            <SelectTrigger id="startDay">
              <SelectValue placeholder="Sélectionnez le jour" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sunday">Dimanche</SelectItem>
              <SelectItem value="monday">Lundi</SelectItem>
              <SelectItem value="saturday">Samedi</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-primary" />
            <Label>Heures de travail</Label>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startTime">Début</Label>
              <Select
                value={formData.workStartTime || "09:00"}
                onValueChange={(value) => updateFormData({ workStartTime: value })}
              >
                <SelectTrigger id="startTime">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="06:00">06:00</SelectItem>
                  <SelectItem value="07:00">07:00</SelectItem>
                  <SelectItem value="08:00">08:00</SelectItem>
                  <SelectItem value="09:00">09:00</SelectItem>
                  <SelectItem value="10:00">10:00</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="endTime">Fin</Label>
              <Select
                value={formData.workEndTime || "18:00"}
                onValueChange={(value) => updateFormData({ workEndTime: value })}
              >
                <SelectTrigger id="endTime">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="16:00">16:00</SelectItem>
                  <SelectItem value="17:00">17:00</SelectItem>
                  <SelectItem value="18:00">18:00</SelectItem>
                  <SelectItem value="19:00">19:00</SelectItem>
                  <SelectItem value="20:00">20:00</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <Label>Jours de travail</Label>
          <div className="grid grid-cols-2 gap-2">
            {daysOfWeek.map((day) => (
              <div key={day.id} className="flex items-center space-x-2">
                <Checkbox
                  id={day.id}
                  checked={workDays.includes(day.id)}
                  onCheckedChange={() => toggleWorkDay(day.id)}
                />
                <label htmlFor={day.id} className="cursor-pointer">
                  {day.label}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <Label>Notifications de calendrier</Label>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div>
                <p>Rappels d'événements</p>
                <p className="text-sm text-muted-foreground">
                  15 minutes avant l'événement
                </p>
              </div>
              <Switch
                checked={formData.eventReminders || true}
                onCheckedChange={(checked) => updateFormData({ eventReminders: checked })}
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div>
                <p>Vue hebdomadaire</p>
                <p className="text-sm text-muted-foreground">
                  Résumé chaque dimanche soir
                </p>
              </div>
              <Switch
                checked={formData.weeklyOverview || false}
                onCheckedChange={(checked) => updateFormData({ weeklyOverview: checked })}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
