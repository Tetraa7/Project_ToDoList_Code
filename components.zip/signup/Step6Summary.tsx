import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Separator } from "../ui/separator";
import { User, Mail, Globe, ListTodo, Calendar, Palette, Check } from "lucide-react";
import { Avatar, AvatarFallback } from "../ui/avatar";

interface Step6SummaryProps {
  formData: any;
}

export function Step6Summary({ formData }: Step6SummaryProps) {
  const getThemeLabel = (theme: string) => {
    switch (theme) {
      case "dark":
        return "Sombre";
      case "system":
        return "Système";
      default:
        return "Clair";
    }
  };

  const getViewLabel = (view: string) => {
    switch (view) {
      case "day":
        return "Jour";
      case "month":
        return "Mois";
      case "agenda":
        return "Agenda";
      default:
        return "Semaine";
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2>Récapitulatif</h2>
        <p className="text-muted-foreground mt-1">
          Vérifiez vos informations avant de créer votre compte
        </p>
      </div>

      <div className="space-y-4">
        {/* Profil */}
        <Card className="p-4">
          <div className="flex items-start gap-4">
            <Avatar className="w-16 h-16">
              <AvatarFallback>
                {formData.firstName?.[0]}{formData.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-muted-foreground" />
                <h3>Profil</h3>
              </div>
              <div className="mt-2 space-y-1">
                <p>
                  {formData.firstName} {formData.lastName}
                </p>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="w-3 h-3" />
                  <span>{formData.email}</span>
                </div>
                {formData.bio && (
                  <p className="text-sm text-muted-foreground mt-2">{formData.bio}</p>
                )}
              </div>
            </div>
          </div>
        </Card>

        {/* Paramètres régionaux */}
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Globe className="w-4 h-4 text-muted-foreground" />
            <h3>Paramètres régionaux</h3>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Fuseau horaire</span>
              <span>{formData.timezone || "Europe/Paris"}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Langue</span>
              <span>{formData.language === "fr" ? "Français" : formData.language}</span>
            </div>
          </div>
        </Card>

        {/* ToDoList */}
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <ListTodo className="w-4 h-4 text-muted-foreground" />
            <h3>ToDoList</h3>
          </div>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-muted-foreground mb-2">Catégories sélectionnées</p>
              <div className="flex flex-wrap gap-2">
                {formData.todoCategories?.length > 0 ? (
                  formData.todoCategories.map((cat: string) => (
                    <Badge key={cat} variant="secondary">
                      {cat}
                    </Badge>
                  ))
                ) : (
                  <span className="text-sm text-muted-foreground">Aucune catégorie</span>
                )}
              </div>
            </div>
            <Separator />
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Priorité par défaut</span>
              <span className="capitalize">{formData.defaultPriority || "moyenne"}</span>
            </div>
            <div className="space-y-1">
              {formData.taskReminders && (
                <div className="flex items-center gap-2 text-sm">
                  <Check className="w-3 h-3 text-primary" />
                  <span>Rappels de tâches activés</span>
                </div>
              )}
              {formData.dailyDigest && (
                <div className="flex items-center gap-2 text-sm">
                  <Check className="w-3 h-3 text-primary" />
                  <span>Résumé quotidien activé</span>
                </div>
              )}
            </div>
          </div>
        </Card>

        {/* Calendrier */}
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-4 h-4 text-muted-foreground" />
            <h3>Calendrier</h3>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Vue par défaut</span>
              <span>{getViewLabel(formData.defaultView)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Heures de travail</span>
              <span>
                {formData.workStartTime || "09:00"} - {formData.workEndTime || "18:00"}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Jours travaillés</span>
              <span>{formData.workDays?.length || 5} jours</span>
            </div>
          </div>
        </Card>

        {/* Personnalisation */}
        <Card className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Palette className="w-4 h-4 text-muted-foreground" />
            <h3>Personnalisation</h3>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Thème</span>
              <span>{getThemeLabel(formData.theme)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Couleur d'accentuation</span>
              <span className="capitalize">{formData.accentColor || "bleu"}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Disposition</span>
              <span>{formData.layout === "topbar" ? "Barre supérieure" : "Barre latérale"}</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
