import { Label } from "../ui/label";
import { Switch } from "../ui/switch";
import { Checkbox } from "../ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { ListTodo, Bell, Star } from "lucide-react";

interface Step3TodoPreferencesProps {
  formData: any;
  updateFormData: (data: any) => void;
}

const defaultCategories = [
  { id: "work", label: "Travail", color: "#3b82f6" },
  { id: "personal", label: "Personnel", color: "#10b981" },
  { id: "shopping", label: "Courses", color: "#f59e0b" },
  { id: "health", label: "Santé", color: "#ef4444" },
  { id: "learning", label: "Apprentissage", color: "#8b5cf6" },
];

export function Step3TodoPreferences({ formData, updateFormData }: Step3TodoPreferencesProps) {
  const selectedCategories = formData.todoCategories || [];

  const toggleCategory = (categoryId: string) => {
    const newCategories = selectedCategories.includes(categoryId)
      ? selectedCategories.filter((id: string) => id !== categoryId)
      : [...selectedCategories, categoryId];
    updateFormData({ todoCategories: newCategories });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2>Préférences ToDoList</h2>
        <p className="text-muted-foreground mt-1">
          Configurez votre espace de tâches
        </p>
      </div>

      <div className="space-y-6">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <ListTodo className="w-5 h-5 text-primary" />
            <Label>Catégories par défaut</Label>
          </div>
          <p className="text-sm text-muted-foreground">
            Sélectionnez les catégories que vous souhaitez utiliser
          </p>
          <div className="space-y-2">
            {defaultCategories.map((category) => (
              <div key={category.id} className="flex items-center space-x-2">
                <Checkbox
                  id={category.id}
                  checked={selectedCategories.includes(category.id)}
                  onCheckedChange={() => toggleCategory(category.id)}
                />
                <label
                  htmlFor={category.id}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: category.color }}
                  />
                  <span>{category.label}</span>
                </label>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-primary" />
            <Label htmlFor="defaultPriority">Priorité par défaut</Label>
          </div>
          <Select
            value={formData.defaultPriority || "medium"}
            onValueChange={(value) => updateFormData({ defaultPriority: value })}
          >
            <SelectTrigger id="defaultPriority">
              <SelectValue placeholder="Sélectionnez la priorité" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Basse</SelectItem>
              <SelectItem value="medium">Moyenne</SelectItem>
              <SelectItem value="high">Haute</SelectItem>
              <SelectItem value="urgent">Urgente</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-primary" />
            <Label>Notifications de tâches</Label>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div>
                <p>Rappels de tâches</p>
                <p className="text-sm text-muted-foreground">
                  Recevoir des rappels avant l'échéance
                </p>
              </div>
              <Switch
                checked={formData.taskReminders || false}
                onCheckedChange={(checked) => updateFormData({ taskReminders: checked })}
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div>
                <p>Tâches quotidiennes</p>
                <p className="text-sm text-muted-foreground">
                  Résumé quotidien de vos tâches
                </p>
              </div>
              <Switch
                checked={formData.dailyDigest || false}
                onCheckedChange={(checked) => updateFormData({ dailyDigest: checked })}
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div>
                <p>Tâches complétées</p>
                <p className="text-sm text-muted-foreground">
                  Notifications lors de la complétion
                </p>
              </div>
              <Switch
                checked={formData.completionNotifications || false}
                onCheckedChange={(checked) => updateFormData({ completionNotifications: checked })}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
