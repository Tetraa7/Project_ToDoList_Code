import { Label } from "../ui/label";
import { RadioGroup, RadioGroupItem } from "../ui/radio-group";
import { Palette, Layout, Moon, Sun, Laptop } from "lucide-react";

interface Step5CustomizationProps {
  formData: any;
  updateFormData: (data: any) => void;
}

const accentColors = [
  { id: "blue", label: "Bleu", color: "#3b82f6" },
  { id: "purple", label: "Violet", color: "#8b5cf6" },
  { id: "green", label: "Vert", color: "#10b981" },
  { id: "orange", label: "Orange", color: "#f97316" },
  { id: "pink", label: "Rose", color: "#ec4899" },
  { id: "red", label: "Rouge", color: "#ef4444" },
];

export function Step5Customization({ formData, updateFormData }: Step5CustomizationProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2>Personnalisation</h2>
        <p className="text-muted-foreground mt-1">
          Créez votre espace à votre image
        </p>
      </div>

      <div className="space-y-6">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Sun className="w-5 h-5 text-primary" />
            <Label>Thème de l'interface</Label>
          </div>
          <RadioGroup
            value={formData.theme || "light"}
            onValueChange={(value) => updateFormData({ theme: value })}
          >
            <div className="grid grid-cols-3 gap-3">
              <label
                htmlFor="light"
                className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  formData.theme === "light" || !formData.theme
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-muted-foreground"
                }`}
              >
                <Sun className="w-8 h-8" />
                <RadioGroupItem value="light" id="light" className="sr-only" />
                <span>Clair</span>
              </label>

              <label
                htmlFor="dark"
                className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  formData.theme === "dark"
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-muted-foreground"
                }`}
              >
                <Moon className="w-8 h-8" />
                <RadioGroupItem value="dark" id="dark" className="sr-only" />
                <span>Sombre</span>
              </label>

              <label
                htmlFor="system"
                className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  formData.theme === "system"
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-muted-foreground"
                }`}
              >
                <Laptop className="w-8 h-8" />
                <RadioGroupItem value="system" id="system" className="sr-only" />
                <span>Système</span>
              </label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Palette className="w-5 h-5 text-primary" />
            <Label>Couleur d'accentuation</Label>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {accentColors.map((color) => (
              <button
                key={color.id}
                type="button"
                onClick={() => updateFormData({ accentColor: color.id })}
                className={`flex items-center gap-3 p-3 rounded-lg border-2 transition-all ${
                  formData.accentColor === color.id || (!formData.accentColor && color.id === "blue")
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-muted-foreground"
                }`}
              >
                <div
                  className="w-6 h-6 rounded-full"
                  style={{ backgroundColor: color.color }}
                />
                <span>{color.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Layout className="w-5 h-5 text-primary" />
            <Label>Disposition de l'interface</Label>
          </div>
          <RadioGroup
            value={formData.layout || "sidebar"}
            onValueChange={(value) => updateFormData({ layout: value })}
          >
            <div className="space-y-3">
              <label
                htmlFor="sidebar"
                className={`flex items-start gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  formData.layout === "sidebar" || !formData.layout
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-muted-foreground"
                }`}
              >
                <RadioGroupItem value="sidebar" id="sidebar" className="mt-1" />
                <div className="flex-1">
                  <p>Barre latérale</p>
                  <p className="text-sm text-muted-foreground">
                    Navigation sur le côté gauche
                  </p>
                </div>
                <div className="w-16 h-12 border rounded flex">
                  <div className="w-1/4 bg-muted" />
                  <div className="flex-1 bg-background" />
                </div>
              </label>

              <label
                htmlFor="topbar"
                className={`flex items-start gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  formData.layout === "topbar"
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-muted-foreground"
                }`}
              >
                <RadioGroupItem value="topbar" id="topbar" className="mt-1" />
                <div className="flex-1">
                  <p>Barre supérieure</p>
                  <p className="text-sm text-muted-foreground">
                    Navigation en haut de la page
                  </p>
                </div>
                <div className="w-16 h-12 border rounded flex flex-col">
                  <div className="h-1/4 bg-muted" />
                  <div className="flex-1 bg-background" />
                </div>
              </label>
            </div>
          </RadioGroup>
        </div>
      </div>
    </div>
  );
}
