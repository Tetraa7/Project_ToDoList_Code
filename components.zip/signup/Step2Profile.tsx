import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Upload } from "lucide-react";
import { Button } from "../ui/button";

interface Step2ProfileProps {
  formData: any;
  updateFormData: (data: any) => void;
}

export function Step2Profile({ formData, updateFormData }: Step2ProfileProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2>Personnalisez votre profil</h2>
        <p className="text-muted-foreground mt-1">
          Ajoutez quelques détails pour compléter votre profil
        </p>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Photo de profil</Label>
          <div className="flex items-center gap-4">
            <Avatar className="w-20 h-20">
              <AvatarImage src={formData.avatarUrl} />
              <AvatarFallback>
                {formData.firstName?.[0]}{formData.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <Button variant="outline" type="button">
              <Upload className="w-4 h-4 mr-2" />
              Télécharger une photo
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="bio">Bio (optionnel)</Label>
          <Textarea
            id="bio"
            placeholder="Parlez-nous un peu de vous..."
            rows={4}
            value={formData.bio || ""}
            onChange={(e) => updateFormData({ bio: e.target.value })}
          />
          <p className="text-xs text-muted-foreground">
            {formData.bio?.length || 0}/200 caractères
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="timezone">Fuseau horaire</Label>
          <Select
            value={formData.timezone || "Europe/Paris"}
            onValueChange={(value) => updateFormData({ timezone: value })}
          >
            <SelectTrigger id="timezone">
              <SelectValue placeholder="Sélectionnez votre fuseau horaire" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Europe/Paris">Europe/Paris (GMT+1)</SelectItem>
              <SelectItem value="Europe/London">Europe/London (GMT+0)</SelectItem>
              <SelectItem value="America/New_York">America/New York (GMT-5)</SelectItem>
              <SelectItem value="America/Los_Angeles">America/Los Angeles (GMT-8)</SelectItem>
              <SelectItem value="Asia/Tokyo">Asia/Tokyo (GMT+9)</SelectItem>
              <SelectItem value="Australia/Sydney">Australia/Sydney (GMT+11)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="language">Langue</Label>
          <Select
            value={formData.language || "fr"}
            onValueChange={(value) => updateFormData({ language: value })}
          >
            <SelectTrigger id="language">
              <SelectValue placeholder="Sélectionnez votre langue" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="fr">Français</SelectItem>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="es">Español</SelectItem>
              <SelectItem value="de">Deutsch</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}
